# Uses https://github.com/divmain/fuzzponent
mkdir fixtures
cd fixtures
fuzzponent -d 2 -s 20
