# Failed to load `BUILD_ID` from Server

#### Why This Error Occurred

The deployment was generated incorrectly or the server was overloaded at the time of the request.

#### Possible Ways to Fix It

Please make sure you are using the latest version of the `@vercel/next` builder in your `vercel.json`.
If this error persists, please file a bug report.
