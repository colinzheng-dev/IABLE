export default function Day() {
  return <div>Hello Day</div>
}
