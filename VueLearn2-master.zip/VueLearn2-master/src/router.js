import Vue from "vue";
import VueRouter from "vue-router";

import Index from "./pages/Index";

// import Hitting from "./pages/Hitting"
import Pitching from "./pages/Fastpitch_National_Pitching/Pitching";
import Defense from "./pages/Fastpitch_National_Defensive/Defense";

import EventPage from "./pages/EventsPage";
import Events from "./pages/Events";
import EventPageHitting from "./pages/Fastpitch_Events_Hitting/HittingEventPage";
import EventPagePitching from "./pages/Fastpitch_Events_Pitching/PitchingEventPage";
import EventPageDefense from "./pages/Fastpitch_Events_Defensive/DefenseEventPage";
import BaseballEventsPage from "./pages/BaseballEventsPage";
import BaseballHittingEventPage from "./pages/Baseball_Events_Hitting/BaseballHittingEventPage";
import BaseballDefenseEventPage from "./pages/Baseball_Events_Defensive/BaseballDefenseEventPage";
import BaseballPitchingEventPage from "./pages/Baseball_Events_Pitching/BaseballPitchingEventPage";
import HittingNationalPage from "./pages/Fastpitch_National_Hitting/HittingNationalPage";
import MQHitting from "./pages/MQ_Hitting_Events.vue";
import MQPitching from "./pages/MQ_Pitching_Events.vue";
import MQDefense from "./pages/MQ_Defense_Events.vue";
import MQHittingPage from "./pages/MQ_Hitting/Main.vue";
import MQEventsPage from "./pages/MQEventsPage.vue";
import MQDefensePage from "./pages/Fastpitch_MQ_Defense/Main.vue";

Vue.use(VueRouter);
const routes = [
  {
    path: "/",
    redirect: "/events"
  },
  {
    path: "/fastpitch",
    component: Index,
    children: [
      {
        path: "hitting",
        component: HittingNationalPage,
        props: {
          path: "/fastpitch"
        }
      },
      {
        path: "pitching",
        component: Pitching
      },
      {
        path: "defense",
        component: Defense
      }
    ]
  },
  {
    path: "/events/",
    component: Events
  },
  {
    path: "/mq-events/hitting",
    component: MQHitting
  },
  {
    path: "/mq-events/pitching",
    component: MQPitching
  },
  {
    path: "/mq-events/defense",
    component: MQDefense
  },
  {
    path: "/mq-events/fastpitch/:eventId",
    component: MQEventsPage,
    children: [
      {
        path: "hitting",
        component: MQHittingPage
      },
      {
        path: "pitching",
        component: EventPagePitching
      },
      {
        path: "defense",
        component: MQDefensePage
      }
    ]
  },
  {
    path: "/events/fastpitch/:eventId",
    component: EventPage,
    children: [
      {
        path: "hitting",
        component: EventPageHitting
      },
      {
        path: "pitching",
        component: EventPagePitching
      },
      {
        path: "defense",
        component: EventPageDefense
      }
    ]
  },
  {
    path: "/events/baseball/:eventId",
    component: BaseballEventsPage,
    children: [
      {
        path: "hitting",
        component: BaseballHittingEventPage
      },
      {
        path: "pitching",
        component: BaseballPitchingEventPage
      },
      {
        path: "defense",
        component: BaseballDefenseEventPage
      }
    ]
  }
];

const router = new VueRouter({
  base: "/",
  mode: "history",
  routes
});

export default router;
