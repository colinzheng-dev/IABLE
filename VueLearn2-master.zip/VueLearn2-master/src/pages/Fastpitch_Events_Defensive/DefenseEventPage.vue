<template>
  <div>
    <!-- <VueSocialSharing /> -->
    <div class="mx-auto px-4">
      <div>
        <div class="flex flex-wrap overflow-hidden xl:-mx-1 p-4">
          <div
            class="w-full overflow-hidden xl:my-1 xl:px-1 xl:w-1/4 md:w-1/4 sm:w-1/4"
          >
            <!-- Column Content -->

            <div
              @click="toggleCategoryDropdown = !toggleCategoryDropdown"
              class="flex flex-wrap my-1 justify-center w-full rounded-md border border-gray-300 shadow-sm px-4 py-2 bg-white text-sm font-medium text-gray-700 hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-offset-gray-100 focus:ring-indigo-500"
            >
              Select A Category
              <svg
                class="-mr-1 ml-2 h-5 w-5"
                xmlns="http://www.w3.org/2000/svg"
                viewBox="0 0 20 20"
                fill="currentColor"
                aria-hidden="true"
              >
                <path
                  fill-rule="evenodd"
                  d="M5.293 7.293a1 1 0 011.414 0L10 10.586l3.293-3.293a1 1 0 111.414 1.414l-4 4a1 1 0 01-1.414 0l-4-4a1 1 0 010-1.414z"
                  clip-rule="evenodd"
                />
              </svg>
            </div>
            <div
              class="bg-white text-base z-50 float-left py-2 px-4 list-none text-left w-full rounded shadow-lg m-1"
              v-if="toggleCategoryDropdown"
            >
              <div class="flex flex-col items-left justify-left">
                <div>
                  <label class="inline-flex items-left mt-3">
                    <input
                      v-model="filters.category.cse"
                      type="checkbox"
                      id="CSE overall"
                      name="CSE overall"
                      class="form-checkbox h-5 w-5 text-theme-1"
                      checked
                    /><span class="ml-2 text-theme-1">CSE Overall</span>
                  </label>
                </div>
                <div>
                  <label class="inline-flex items-left mt-3">
                    <input
                      v-model="filters.category.defensivesubjective"
                      type="checkbox"
                      id="defensivesubjective"
                      name="defensivesubjective"
                      class="form-checkbox h-5 w-5 text-theme-1"
                      checked
                    /><span class="ml-2 text-theme-1"
                      >Defensive Subjective</span
                    >
                  </label>
                </div>
                <div>
                  <label class="inline-flex items-left mt-3">
                    <input
                      v-model="filters.category.overhandvelocity"
                      type="checkbox"
                      id="overhandvelocity"
                      name="overhandvelocity"
                      class="form-checkbox h-5 w-5 text-theme-1"
                      checked
                    /><span class="ml-2 text-theme-1">Overhand Velocity</span>
                  </label>
                </div>
                <div>
                  <label class="inline-flex items-left mt-3">
                    <input
                      v-model="filters.category.hometofirst"
                      type="checkbox"
                      id="hometofirst"
                      name="hometofirst"
                      class="form-checkbox h-5 w-5 text-theme-1"
                      checked
                    /><span class="ml-2 text-theme-1">Home to First</span>
                  </label>
                </div>
                <div>
                  <label class="inline-flex items-left mt-3">
                    <input
                      v-model="filters.category.hometohome"
                      type="checkbox"
                      id="hometohome"
                      name="hometohome"
                      class="form-checkbox h-5 w-5 text-theme-1"
                      checked
                    /><span class="ml-2 text-theme-1">Home to Home</span>
                  </label>
                </div>
                <div>
                  <label class="inline-flex items-left mt-3">
                    <input
                      v-model="filters.category.poptime"
                      type="checkbox"
                      id="poptime"
                      name="poptime"
                      class="form-checkbox h-5 w-5 text-theme-1"
                      checked
                    /><span class="ml-2 text-theme-1">Pop Time</span>
                  </label>
                </div>
              </div>
            </div>
          </div>

          <div
            class="w-full overflow-hidden xl:my-1 xl:px-1 xl:w-1/4 md:w-1/4 sm:w-1/4"
          >
            <!-- Column Content -->
            <div
              @click="toggleFilterDropdown = !toggleFilterDropdown"
              class="flex flex-wrap justify-center my-1 w-full rounded-md border border-gray-300 shadow-sm px-4 py-2 bg-white text-sm font-medium text-gray-700 hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-offset-gray-100 focus:ring-indigo-500"
            >
              Filter by Position
              <svg
                class="-mr-1 ml-2 h-5 w-5"
                xmlns="http://www.w3.org/2000/svg"
                viewBox="0 0 20 20"
                fill="currentColor"
                aria-hidden="true"
              >
                <path
                  fill-rule="evenodd"
                  d="M5.293 7.293a1 1 0 011.414 0L10 10.586l3.293-3.293a1 1 0 111.414 1.414l-4 4a1 1 0 01-1.414 0l-4-4a1 1 0 010-1.414z"
                  clip-rule="evenodd"
                />
              </svg>
            </div>
            <div
              class="bg-white text-base z-50 float-left py-2 px-4 list-none text-left w-full rounded shadow-lg m-1"
              v-if="toggleFilterDropdown"
            >
              <div class="flex flex-col items-left justify-left">
                <div class="flex flex-col">
                  <label class="inline-flex items-left mt-3">
                    <input
                      v-model="filters.position.Outfield"
                      type="checkbox"
                      value="Outfield"
                      class="form-checkbox h-5 w-5 text-theme-1"
                      checked
                    /><span class="ml-2 text-theme-1">Outfield</span>
                  </label>

                  <label class="inline-flex items-left mt-3">
                    <input
                      v-model="filters.position.Catcher"
                      type="checkbox"
                      value="Catcher"
                      class="form-checkbox h-5 w-5 text-theme-1"
                      checked
                    /><span class="ml-2 text-gray-700">Catcher</span>
                  </label>
                  <!-- <label class="inline-flex items-left mt-3">
                    <input
                      v-model="positionFilter"
                      type="checkbox"
                      value="Middle Infield"
                      class="form-checkbox h-5 w-5 text-theme-1"
                      checked
                    /><span class="ml-2 text-gray-700">Middle Infield</span>
                  </label> -->
                  <label class="inline-flex items-left mt-3">
                    <input
                      v-model="filters.position.Corner"
                      type="checkbox"
                      value="Corner"
                      class="form-checkbox h-5 w-5 text-theme-1"
                      checked
                    /><span class="ml-2 text-gray-700">Corner</span>
                  </label>
                </div>
              </div>
            </div>
          </div>

          <div class="w-full overflow-hidden xl:my-1 xl:px-1 xl:w-1/4">
            <!-- Column Content -->
          </div>

          <div class="w-full overflow-hidden xl:my-1 xl:px-1 xl:w-1/4">
            <!-- Column Content -->
          </div>
        </div>
      </div>
    </div>

    <defense-leaderboard
      :data="players"
      @click="scoreClick"
      :category="filters.category"
      :position="filters.position"
    />
  </div>
</template>

<script>
import Popper from "popper.js";
// import VueSocialSharing from "vue-social-sharing";
import axios from "axios";
import DefenseLeaderboard from "@/components/DefenseLeaderboard";

export default {
  name: "DefenseEventPage",
  data() {
    return {
      eventId: "",
      toggleFilterDropdown: false,
      toggleCategoryDropdown: false,
      colDataFetchingLoading: false,
      colDataFetchingError: false,
      players: [],
      showFilter: true,
      selectedScore: 0,
      positionFilter: [
        "Outfield",
        "Catcher",
        "Middle Infield",
        "Corner",
        "Pitcher"
      ],
      pageNum: 1,
      highlightColName: "",
      filterRoute: [
        "hitting",
        "cse",
        "defensiveSubjective",
        "overhandVelocity",
        "verticalBreak",
        "poptime"
      ],
      filters: {
        filter: this.$route.query.filter || "",
        showCategory: true,
        category: {
          cse: true,
          defensivesubjective: true,
          overhandvelocity: true,
          hometofirst: true,
          hometohome: true,
          poptime: true
        },
        position: {
          Outfield: true,
          Catcher: true,
          // MiddleInfield: true,
          Corner: true
        }
      },
      sortCol: {
        name: "subj_collegefit_overall_scoreweighted_conv2080",
        order: "desc"
      }
    };
  },
  components: { DefenseLeaderboard },
  computed: {
    getEventId() {
      return this.$store.getters["events/getEventId"];
    },
    isDataExists() {
      return this.$store.getters["events/getRenderingState"].data;
    },
    getActiveColName() {
      return this.$store.getters["events/activeColName"];
    },
    getFilters(filter) {
      return this.filterRoute.includes(filter);
    }
  },
  methods: {
    async getEventData() {
      try {
        const response = await axios({
          method: "GET",
          url: `https://cse-api.herokuapp.com/products/getevent/${this.$route.params.eventId}`
        });

        this.eventId = response.data.event[0].cse_eventid;
        console.log("getEventData method");
        await this.getEvents();
      } catch (error) {
        console.log("getEventData method error");
        console.log(error);
      }
    },
    async getEvents() {
      this.$store.commit("events/updateRendering", {
        loading: true
      });

      this.colDataFetchingLoading = true;
      this.loading = true;
      try {
        const eventId = this.eventId;
        this.players = [];

        const postionParams = [];

        for (const key in this.filters.position) {
          if (this.filters.position[key]) {
            postionParams.push(key);
          }
        }

        const players = await axios({
          method: "GET",
          url: `https://cse-api.herokuapp.com/leaderboard/fastpitch/defense/${eventId}`,
          params: {
            tg_position: postionParams.join(","),
            sort: `${this.sortCol.name}:${this.sortCol.order}`
          }
        });
        const data = players.data.leaderboard;

        for (let i = 0; i < data.length; i++) {
          const element = data[i];
          this.players.push({
            id: element.cse_playerid,
            name: element.first_name,
            lastName: element.last_name,
            cseScore: element.subj_collegefit_overall_scoreweighted_conv2080,
            defensiveSubjective: element.subj_collegefit_defense_scoreconv2080,
            overhandVelocity: element.max_arm_velo,
            hometoFirst: element.home_to_1,
            hometoHome: element.home_to_home,
            popTime: element.min_pop_time,
            sport: element.tg_position
            // eventName: element.cse_eventid.eventName,
          });
        }
        this.$store.commit("events/updateRendering", {
          data: true
        });
      } catch (error) {
        console.log("getEvents method API");
        console.log({ ...error });
        this.$store.commit("events/updateRendering", {
          error: true
        });
      } finally {
        this.loading = false;

        this.$store.commit("events/updateRendering", {
          loading: false
        });
      }
    },
    loadMore() {
      // this.pageNum++
      this.pageNum = this.pageNum + 1;

      this.getEvents();
    },
    scoreClick(event) {
      console.log(event);
      const score = parseFloat(event);
      // this.selectedScore = (3 / 5) * score + 20;
      this.selectedScore = score;
    },
    updateFilter() {
      const categoryFilter = this.$route.query.category?.split(",");
      const positionFilter = this.$route.query.position?.split(",");
      // const localFilter = this.$route.query.filter.split(",");

      // category filter
      const categoryObj = this.filters.category;

      for (const key in categoryObj) {
        this.filters.category[key] = false;
        if (categoryFilter.includes(key)) {
          this.filters.category[key] = true;
        }
      }

      // position filter
      const positionObj = this.filters.position;
      for (const key in positionObj) {
        this.filters.position[key] = false;
        if (positionFilter.includes(key)) {
          this.filters.position[key] = true;
        }
      }
    },
    toggleDropdown: function() {
      if (this.dropdownPopoverShow) {
        this.dropdownPopoverShow = false;
      } else {
        this.dropdownPopoverShow = true;
        new Popper(this.$refs.btnDropdownRef, this.$refs.popoverDropdownRef, {
          placement: "bottom-start"
        });
      }
    },

    togglePositionDropdown: function() {
      if (this.dropdownPopoverShow) {
        this.dropdownPopoverShow = false;
      } else {
        this.dropdownPopoverShow = true;
        new Popper(this.$refs.btnDropdownRef, this.$refs.popoverDropdownRef, {
          placement: "bottom-start"
        });
      }
    },

    highlightColumn(e) {
      console.log("col name highlight");
      console.log(e);
      this.highlightColName = e;

      for (let i = 0; i < this.players.length; i++) {
        // const item = this.players[i];
      }
    }
  },
  watch: {
    getActiveColName: {
      handler(newVal) {
        this.sortCol.name = newVal;

        this.getEvents();
      }
    },
    "filters.category": {
      handler(newVal) {
        const val = Object.keys(newVal).filter(id => {
          return newVal[id];
        });

        this.$router.push({
          // path: `${this.$route.matched[0].path}/hitting`,
          path: `/events/fastpitch/${this.getEventId}/defense`,
          query: {
            category: val.join(","),
            position: this.$route.query.position || ""
          }
        });
      },
      deep: true
    },
    "filters.position": {
      handler(newVal) {
        console.log("run the get events method for postions");
        this.getEvents();

        const val = Object.keys(newVal).filter(id => {
          return newVal[id];
        });

        this.$router.push({
          // path: `${this.$route.matched[0].path}/hitting`,
          path: `/events/fastpitch/${this.getEventId}/defense`,
          query: {
            position: val.join(","),
            category: this.$route.query.category || ""
          }
        });
      },
      deep: true
    }
    // positionFilter: function(newVal) {
    //   if (newVal.length === 0) this.positionFilterErrorMessage = true;
    //   console.log("positionFilter watcher");
    //   this.getEvents();
    // },
  },
  mounted() {
    // mutation for the selected col in vuex
    this.$store.commit(
      "events/updateColName",
      "subj_collegefit_overall_scoreweighted_conv2080"
    );
  },
  created() {
    this.getEventData();
    // this.getData();

    if (this.$route.query.category || this.$route.query.position) {
      this.updateFilter();
    }
  }
};
</script>

<style lang="css">
div.sticky {
  position: -webkit-sticky; /* Safari */
  position: sticky;
  top: 0;
  padding-top: 20px;
}

.checkbox-input {
  display: none;
}

.checkbox {
  border: 1px solid red;
  border-radius: 3px;
  width: 20px;
  height: 20px;
}
</style>
