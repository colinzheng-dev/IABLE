<template>
  <div>
    <button @click="showFilter = !showFilter">Toogle filter</button>

    <div v-if="showFilter">
      <div>
        <div
          @click="
            filters.category.showCategory = !filters.category.showCategory
          "
        ></div>

        <div class="dropdown" v-if="filters.category.showCategory">
          <div>
            <label for="CSE overall">CSE overall</label>
            <input
              v-model="filters.category.cse"
              type="checkbox"
              id="CSE overall"
              name="CSE overall"
            />
          </div>
          <div>
            <label for="hitting">hitting</label>
            <input
              v-model="filters.category.hitting"
              type="checkbox"
              id="hitting"
              name="hitting"
            />
          </div>
          <div>
            <label for="footspeed">footspeed</label>
            <input
              v-model="filters.category.footspeed"
              type="checkbox"
              id="footspeed"
              name="footspeed"
            />
          </div>
          <div>
            <label for="throw">throw</label>
            <input
              v-model="filters.category.throw"
              type="checkbox"
              id="throw"
              name="throw"
            />
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
export default {
  data() {
    return {
      isConfidenceHidden: false
    };
  }
};
</script>

<style lang="css"></style>
