<template>
	<div>
		{{ categoryFilter }}
	</div>
</template>

<script>
export default {
	name: "CustomComponent",
	props: {
		categoryFilter: {
			type: Object,
			required: true
		},
		positionFilter: {
			type: Object,
			required: true
		}
	},
	watch: {
		categoryFilter: {
			handler(newVal) {
				console.log("newVal");
				console.log(newVal);
			},
			// deep: true
		}
	}
};
</script>
