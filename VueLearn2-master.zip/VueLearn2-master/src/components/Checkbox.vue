<template>
  <div>
    <input
      @input="click"
      type="checkbox"
      :checked="value"
      class="checkbox-input"
    />
    <div class="checkbox">
      <svg
        v-if="value"
        height="100px"
        width="100px"
        fill="#000000"
        xmlns:dc="http://purl.org/dc/elements/1.1/"
        xmlns:cc="http://creativecommons.org/ns#"
        xmlns:rdf="http://www.w3.org/1999/02/22-rdf-syntax-ns#"
        xmlns:svg="http://www.w3.org/2000/svg"
        xmlns="http://www.w3.org/2000/svg"
        xmlns:sodipodi="http://sodipodi.sourceforge.net/DTD/sodipodi-0.dtd"
        xmlns:inkscape="http://www.inkscape.org/namespaces/inkscape"
        version="1.1"
        x="0px"
        y="0px"
        viewBox="0 0 100 100"
      >
        <g transform="translate(0,-952.36218)">
          <path
            style="text-indent:0;text-transform:none;direction:ltr;block-progression:tb;baseline-shift:baseline;color:#000000;enable-background:accumulate;"
            d="m 74.98437,979.84653 -2.84375,2.8125 c -9.92627,9.9478 -20.55148,21.34647 -30.46874,31.40627 l -14.15625,-11.6563 -3.0625,-2.56247 -5.09375,6.18747 3.09375,2.5313 17,14 2.78125,2.3125 2.59375,-2.5625 c 10.74854,-10.7717 22.41522,-23.39227 32.99999,-33.99997 l 2.8125,-2.8438 -5.65625,-5.625 z"
            fill="#000000"
            fill-opacity="1"
            stroke="none"
            marker="none"
            visibility="visible"
            display="inline"
            overflow="visible"
          ></path>
        </g>
      </svg>
    </div>
  </div>
</template>

<script>
export default {
  name: "Checbox",
  props: {
    value: Boolean
  },
  methods: {
    click(value) {
      this.$emit("input", value.target.checked);
    }
  }
};
</script>

<style lang="css">
.checkbox-input {
  display: none;
}

.checkbox {
  border: 1px solid red;
  border-radius: 3px;
  width: 20px;
  height: 20px;
}
</style>
