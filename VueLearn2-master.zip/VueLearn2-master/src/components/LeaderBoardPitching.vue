<template>
  <div>
    <table>
      <thead>
        <tr>
          <th>Rank</th>
          <th>Player info</th>

          <th v-if="showCse">CSE Overall Score</th>

          <th v-if="showHitting">Hitting</th>

          <th v-if="showThrow">Throw</th>
          <th v-if="showFootspeed">Foot speed</th>
          <th v-if="showVerticalBreak">Foot speed</th>
        </tr>
      </thead>

      <tbody>
        <tr
          v-for="(player, index) in data"
          :key="player.cse_playerid"
          class="player"
        >
          <td>
            {{ index + 1 }}
          </td>

          <td>
            {{ player.playerfirstname }}
          </td>

          <td
            @click="
              emit(
                player.player_fpcse,
                'subj_collegefit_footspeed_score',
                index
              )
            "
            v-if="showCse"
            :class="{
              selectedRow:
                getSelection.colName === 'subj_collegefit_footspeed_score' &&
                getSelection.index === index,
            }"
          >
            {{
              player.player_fpcse &&
                player.player_fpcse[0].subj_collegefit_footspeed_score
            }}
          </td>

          <td
            @click="
              emit(
                player.player_fpcse,
                'Subj_CollegeFit_OffensePower_ScoreConv2080'
              )
            "
            v-if="showHitting"
          >
            {{
              player.player_fpcse &&
                player.player_fpcse[0]
                  .Subj_CollegeFit_OffensePower_ScoreConv2080
            }}
          </td>

          <td
            @click="emit(player.player_fpcse, 'obj_poptime_throw2', index)"
            v-if="showThrow"
            :class="{
              selectedRow:
                getSelection.colName === 'obj_poptime_throw2' &&
                getSelection.index === index,
            }"
          >
            {{
              player.player_fpcse && player.player_fpcse[0].obj_poptime_throw2
            }}
          </td>

          <td
            @click="emit(player.player_fpcse, 'obj_footspeed_h11', false)"
            v-if="showFootspeed"
          >
            {{
              player.player_fpcse && player.player_fpcse[0].obj_footspeed_h11
            }}
          </td>
        </tr>
      </tbody>
    </table>
  </div>
</template>

<script>
export default {
  name: "LeaderBoardPitching",
  data() {
    return {
      loading: false,
      filter: {
        cse: true,
        hitting: true,
        footspeed: true,
        throw: true,
      },
    };
  },
  // rank player name cse, hitting, actvity
  props: {
    data: {
      type: Array,
      default: () => [],
    },
    showCse: Boolean,
    showHitting: Boolean,
    showFootspeed: Boolean,
    showThrow: Boolean,
  },
  computed: {
    getSelection() {
      return this.$store.getters["getSelected"];
    },
  },
  methods: {
    emit(data, object, index) {
      let value = parseFloat(data[0][object]);
      if (["obj_footspeed_h11", "obj_poptime_throw2"].includes(object)) {
        value = 0;
        console.log("value is 0");
      }

      this.$store.commit("updateSelection", {
        index,
        colName: object,
      });

      this.$store.commit("updateScore", value);
    },
  },
  watch: {
    showCse: {
      handler(newVal) {
        this.filter = {
          ...this.filter,
          cse: newVal,
        };
      },
    },
    showHitting: {
      handler(newVal) {
        this.filter = {
          ...this.filter,
          hitting: newVal,
        };
      },
    },
    showFootspeed: {
      handler(newVal) {
        this.filter = {
          ...this.filter,
          footspeed: newVal,
        };
      },
    },
    showThrow: {
      handler(newVal) {
        this.filter = {
          ...this.filter,
          throw: newVal,
        };
      },
    },
  },
};
</script>

<style lang="css" scoped>
.player {
  margin-bottom: 1rem;
}

.col-cse {
  background: red;
  margin-bottom: 1rem;
}

.selectedRow {
  color: pink;
}
</style>
