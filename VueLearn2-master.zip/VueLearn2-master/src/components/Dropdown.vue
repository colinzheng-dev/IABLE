<template>
  <div class="flex flex-wrap">
    <div class="w-full sm:w-6/12 md:w-4/12 px-4">
      <div class="relative inline-flex align-middle w-full">
        <button
          class="text-white font-bold uppercase text-sm px-6 py-3 rounded shadow hover:shadow-lg outline-none focus:outline-none mr-1 mb-1 bg-gray-800"
          style="transition:all .15s ease font-normal px-6 py-2 rounded outline-none focus:outline-none mr-1 mb-1 capitalize"
          type="button"
          v-on:click="toggleDropdown()"
          ref="btnDropdownRef"
        >
          White Dropdown
        </button>
        <div
          v-bind:class="{
            hidden: !dropdownPopoverShow,
            block: dropdownPopoverShow
          }"
          class="bg-white text-base z-50 float-left py-2 list-none text-left rounded shadow-lg mt-1"
          style="min-width:12rem"
          ref="popoverDropdownRef"
        >
          <a
            href="#pablo"
            class="text-sm py-2 px-4 font-normal block w-full whitespace-no-wrap bg-transparent  text-gray-800"
          >
            Action
          </a>
          <a
            href="#pablo"
            class="text-sm py-2 px-4 font-normal block w-full whitespace-no-wrap bg-transparent  text-gray-800"
          >
            Another action
          </a>
          <a
            href="#pablo"
            class="text-sm py-2 px-4 font-normal block w-full whitespace-no-wrap bg-transparent  text-gray-800"
          >
            Something else here
          </a>
          <div
            class="h-0 my-2 border border-solid border-t-0 border-gray-900 opacity-25"
          ></div>
          <a
            href="#pablo"
            class="text-sm py-2 px-4 font-normal block w-full whitespace-no-wrap bg-transparent  text-gray-800"
          >
            Seprated link
          </a>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import Popper from "popper.js";

export default {
  name: "dropdown",
  data() {
    return {
      dropdownPopoverShow: false
    };
  },
  methods: {
    toggleDropdown: function() {
      if (this.dropdownPopoverShow) {
        this.dropdownPopoverShow = false;
      } else {
        this.dropdownPopoverShow = true;
        new Popper(this.$refs.btnDropdownRef, this.$refs.popoverDropdownRef, {
          placement: "bottom-start"
        });
      }
    }
  }
};
</script>
